let openshopping = document.querySelector('.shopping');
let CloseShopping = document.querySelector('.CloseShopping');
let list = document.querySelector('.list');
let listcard = document.querySelector('.listcard');
let body = document.querySelector('body');
let total = document.querySelector('.total');
let quantity = document.querySelector('.quantity');

openshopping.addEventListener('click', () => {
    body.classList.add('active');
    document.querySelector('.shopping-cart').classList.add('active');
    CloseShopping.style.display = 'block'; // Show the close button
});

CloseShopping.addEventListener('click', () => {
    body.classList.remove('active');
    document.querySelector('.shopping-cart').classList.remove('active');
    CloseShopping.style.display = 'none'; // Hide the close button
});

let products = [
    {
        id: 1,
        name: 'product name 1',
        image: 'static/img/stamp.jpg',
        price: 40
    },
    {
        id: 2,
        name: 'product name 2',
        image: 'static/img/rubber.jpg',
        price: 40
    },
    {
        id: 3,
        name: 'product name 3',
        image: 'static/img/stamp.jpg',
        price: 40
    },
    {
        id: 4,
        name: 'product name 4',
        image: 'static/img/stamp.jpg',
        price: 40
    },
    {
        id: 5,
        name: 'product name 1',
        image: 'static/img/stamp.jpg',
        price: 40
    },
    {
        id: 6,
        name: 'product name 1',
        image: 'static/img/stamp.jpg',
        price: 40
    },
];

let listCards = [];
function initApp() {
    products.forEach((value, key) => {
        let newDiv = document.createElement('div');
        newDiv.innerHTML = `
            <img src="${value.image}" alt="${value.name}"/>
            <div class="title">${value.name}</div>
            <div class="price">$${value.price.toLocaleString()}</div>
            <button onClick="addToCard(${key})">Add To Cart</button>
        `;
        list.appendChild(newDiv);
    });
}
initApp();

function addToCard(key) {
    if (listCards[key] == null) {
        listCards[key] = products[key];
        listCards[key].quantity = 1;
    } else {
        listCards[key].quantity++;
    }
    reloadCard();
}

function ChangeQuantity(key, quantity) {
    if (quantity <= 0) {
        listCards[key] = null;
    } else {
        listCards[key].quantity = quantity;
    }
    reloadCard();
}

function reloadCard() {
    listcard.innerHTML = '';
    let count = 0;
    let totalPrice = 0;
    listCards.forEach((value, key) => {
        if (value != null) {
            totalPrice += value.price * value.quantity;
            count += value.quantity;

            let newDiv = document.createElement('div');
            newDiv.innerHTML = `
                <div><img src="${value.image}" alt="${value.name}"/></div>
                <div>${value.name}</div>
                <div>$${value.price.toLocaleString()}</div>
                <div>${value.quantity}</div>
                <div>
                    <button onclick="ChangeQuantity(${key}, ${value.quantity - 1})">-</button>
                    <div class="count">${value.quantity}</div>
                    <button onclick="ChangeQuantity(${key}, ${value.quantity + 1})">+</button>
                </div>
            `;
            listcard.appendChild(newDiv);
        }
    });

    total.innerText = `Total: $${totalPrice.toLocaleString()}`;
    quantity.innerText = `Quantity: ${count}`;
}