from flask import Flask, render_template, request, redirect, url_for, flash,send_file
from werkzeug.utils import secure_filename
from datetime import datetime
import os
from pymongo import MongoClient
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from io import BytesIO

app = Flask(__name__)

# Configuration
app.config['UPLOAD_FOLDER'] = 'uploads'  # Folder to save uploaded files
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif', 'pdf'}  # Allowed file extensions
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'a_really_secure_random_string')  # Secure key for session management

# MongoDB connection
client = MongoClient(os.getenv('MONGODB_URI', 'mongodb://localhost:27017/'))
db = client['papermart']
users_collection = db['users']
form_collection = db['form']
contacts_collection = db['us']
payment_collection = db['payments']

def allowed_file(filename):
    """
    Checks if the file extension is in the list of allowed extensions.
    """
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        user = users_collection.find_one({'email': email})
        
        if user and user['password'] == password:
            flash('Login successful!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Invalid email or password', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        
        if users_collection.find_one({'email': email}):
            flash('Email address already exists', 'warning')
        else:
            users_collection.insert_one({'name': name, 'email': email, 'password': password})
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/home')
def home():
    return render_template('land.html')

@app.route('/form', methods=['GET', 'POST'])
def form():
    if request.method == 'POST':
        # Extract form data
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        address = request.form.get('message')
        
        # Extract product and total data
        products = request.form.getlist('products[]')
        total_amount = request.form.get('total_amount', 0)

        quantities = {
            'pouch': request.form.get('quantity_pouch', 0),
            'laminator': request.form.get('quantity_laminator', 0),
            'ink': request.form.get('quantity_ink', 0),
            'print': request.form.get('quantity_print', 0)
        }

        # Prepare data for MongoDB
        data = {
            'name': name,
            'email': email,
            'phone': phone,
            'address': address,
            'products': products,
            'quantities': quantities,
            'total': total_amount
        }

        # Insert data into MongoDB
        form_collection.insert_one(data)
        
        return redirect(url_for('payment', total=total_amount))
    
    return render_template('form.html')


@app.route('/payment', methods=['GET', 'POST'])
def payment():
    # Ensure the upload folder exists
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])

    if request.method == 'POST':
        try:
            # Handle file upload
            if 'payment-proof' not in request.files:
                flash('No file part', 'warning')
                return redirect(request.url)
            
            file = request.files['payment-proof']
            
            if file.filename == '':
                flash('No selected file', 'warning')
                return redirect(request.url)
            
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)

                # Save file info to MongoDB
                payment_collection.insert_one({
                    'filename': filename,
                    'file_path': file_path,
                    'uploaded_at': datetime.now()
                })
                
                  # Generate Invoice PDF
                buyer_details = form_collection.find_one(sort=[('_id', -1)])  # Get the latest form submission
                order_id = str(buyer_details['_id'])  # Use MongoDB ObjectId as the order ID
                pdf_buffer = generate_invoice_pdf(buyer_details, order_id)

                # Send the PDF as a downloadable file
                return send_file(pdf_buffer, as_attachment=True, download_name=f"invoice_{order_id}.pdf")
        
        except Exception as e:
            flash(f'An error occurred: {e}', 'danger')
            return redirect(request.url)
        
    total = request.args.get('total', 0)   
    
    return render_template('payment1.html',total=total)

# Function to generate invoice PDF
def generate_invoice_pdf(buyer_details, order_id):
    buffer = BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=letter)

    # Header
    pdf.setFont("Helvetica-Bold", 16)
    pdf.drawString(100, 750, "Invoice")
    pdf.setFont("Helvetica", 12)
    pdf.drawString(100, 730, f"Order ID: {order_id}")
    pdf.drawString(100, 710, f"Name: {buyer_details['name']}")
    pdf.drawString(100, 690, f"Email: {buyer_details['email']}")
    pdf.drawString(100, 670, f"Phone: {buyer_details['phone']}")
    pdf.drawString(100, 650, f"Address: {buyer_details['address']}")

    # Products section
    pdf.drawString(100, 620, "Products Purchased:")
    y_position = 600
    for product, quantity in buyer_details['quantities'].items():
        if int(quantity) > 0:
            pdf.drawString(100, y_position, f"{product.capitalize()}: {quantity}")
            y_position -= 20

    # Total
    pdf.drawString(100, y_position - 20, f"Total Amount: ₹{buyer_details['total']}")

    # Footer
    pdf.drawString(100, y_position - 50, "Thank you for your purchase!")

    # Finalize the PDF
    pdf.showPage()
    pdf.save()

    # Move the buffer's cursor to the beginning
    buffer.seek(0)
    return buffer

@app.route('/thankyou')
def thankyou():
    return render_template('thankyou.html')

@app.route('/reviews')
def reviews():
    return render_template('review.html')

@app.route('/products')
def products():
    return render_template('produ.html')

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        # Get form data
        full_name = request.form.get('name')
        email = request.form.get('email')
        message = request.form.get('message')

        # Create a document
        document = {
            'full_name': full_name,
            'email': email,
            'message': message
        }

        # Insert the document into MongoDB
        contacts_collection.insert_one(document)

        # Redirect to a thank you page or confirmation page
        flash('Message sent successfully!', 'success')
        return redirect(url_for('contact'))

    return render_template('us.html')

if __name__ == '__main__':
    app.run(debug=True)
